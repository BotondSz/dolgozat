'''1. feladat:     7 pont'''
''')	Kérj be 1 páros számot a felhasználótól. (1 pont)
Amennyiben nem páros számot ad meg a felhasználó, akkor kérd be újra a számot, addig, amíg páros számot nem ad meg!  (1 pont)
A bekéréshez írj egy függvényt beker(), amely bekéri a kívánt feltételeknek megfelelő számot. . (1 pont)
"'''

"(A)"

num = int(input("Kérek egy páros számot: "))
if (num % 2) == 0:
   print("{0} Ez a szám páros".format(num))

while not  (num % 2) == 0:
   num = int(input("Ez a szám nem páros, próbáld újra!" ))
   if (num % 2) == 0:
      print("{0} Ez a szám már páros!".format(num))





########################################################################


"(B)"

num = int(input("Kérem az első páros számot: "))
if (num % 2) == 0:
   print("{0} Ez a szám páros".format(num))

while not  (num % 2) == 0:
   num = int(input("Ez nem páros, kérem az első páros számot" ))
   if (num % 2) == 0:
      print("{0} Ez a szám már páros!".format(num))

num = int(input("Kérem a második páros számot: "))
if (num % 2) == 0:
   print("{0} Ez a szám páros".format(num))

while not  (num % 2) == 0:
   num = int(input("Ez nem páros, kérem a második páros számot!" ))
   if (num % 2) == 0:
      print("{0} Ez a szám már páros!".format(num))

num = int(input("Kérem a harmadik páros számot!: "))
if (num % 2) == 0:
   print("{0} Ez a szám páros".format(num))

while not  (num % 2) == 0:
   num = int(input("Ez nem páros, kérem az első páros számot!" ))
   if (num % 2) == 0:
      print("{0} Ez a szám már páros!".format(num))







